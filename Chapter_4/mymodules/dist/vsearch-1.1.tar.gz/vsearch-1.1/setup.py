from setuptools import setup

setup(
    name ='vsearch',
    version='1.1',
    description='Vowel search in a phrase, case insensitive',
    author='hkumar',
    author_email='',
    url='',
    py_modules=['vsearch']




)